const expect = require('chai').expect;
const {Given, When, Then} = require('@cucumber/cucumber');
const { BeforeAll, Before, AfterAll, After } = require('@cucumber/cucumber');
var {setDefaultTimeout} = require('@cucumber/cucumber');
setDefaultTimeout(20 * 1000);
const puppeteer = require('puppeteer');

var browser, page;

BeforeAll (async () => {
    browser = await puppeteer.launch({headless: true});
    page = await browser.newPage();
    page.setDefaultTimeout(20 * 1000);
});

Given ('I browse to google.com', async () => {
    await page.goto('https://google.com', {timeout: 20 * 1000, waitUntil: 'networkidle2'});
});

When ('I type something in the searchbox', async () => {
    let element = await page.$x('.//input[@name="q"]');
    await element[0].type('something');
});

When ('I hit enter', async () => {
    let element = await page.$x('.//input[@name="q"]');
    await element[0].press('Enter');
});

Then ('I should see the results page', async () => {
    await page.waitForTimeout(2000);
    let results = await page.$('div#result-stats');
    expect(await results.evaluate(node => node.innerText)).to.match(/(About ([0-9]{1,3},?)+ results \(([0-9]+\.[0-9]+) seconds\))|(Cerca de ([0-9]{1,3},?)+ resultados \(([0-9]+\.[0-9]+) segundos\))/);
});

AfterAll (async () => {
    await browser.close();
});
